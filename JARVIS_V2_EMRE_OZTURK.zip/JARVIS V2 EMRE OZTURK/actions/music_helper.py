"""
Müzik yardımcısı — Suno prompt, BPM tahmini ve şarkı sözü iskeleti üretir.
LLM çağrısı yapmaz; basit şablonlar kullanır, model üzerine konuşur.
"""

from __future__ import annotations

GENRE_BPM = {
    "trap":      (130, 150),
    "rap":       (85, 100),
    "hiphop":    (85, 100),
    "hip-hop":   (85, 100),
    "drill":     (140, 150),
    "pop":       (100, 130),
    "rock":      (110, 140),
    "metal":     (120, 180),
    "edm":       (120, 130),
    "house":     (118, 130),
    "techno":    (125, 135),
    "lofi":      (70, 90),
    "lo-fi":     (70, 90),
    "rnb":       (60, 90),
    "r&b":       (60, 90),
    "ballad":    (60, 80),
    "balad":     (60, 80),
    "arabesk":   (80, 110),
    "türkü":     (90, 130),
    "turku":     (90, 130),
    "jazz":      (100, 160),
    "reggae":    (60, 90),
    "reggaeton": (90, 100),
}


def _bpm_for(style: str) -> tuple[int, int]:
    s = (style or "").lower()
    for k, v in GENRE_BPM.items():
        if k in s:
            return v
    return (90, 120)


def music_helper(task: str, topic: str = "", style: str = "", mood: str = "") -> str:
    """
    task: 'suno_prompt' | 'bpm' | 'lyrics_skeleton' | 'cover_idea'
    topic: şarkı konusu
    style: tarz (trap, pop, rock, lofi, vb.)
    mood:  duygu (hüzünlü, enerjik, romantik, öfkeli...)
    """
    t = (task or "").strip().lower()
    topic = (topic or "").strip()
    style = (style or "").strip()
    mood  = (mood or "").strip()

    if t == "bpm":
        lo, hi = _bpm_for(style)
        return f"{style or 'belirtilen tarz'} için önerilen BPM aralığı: {lo}-{hi}."

    if t == "suno_prompt":
        lo, hi = _bpm_for(style)
        parts = []
        if style: parts.append(style)
        if mood:  parts.append(mood)
        parts.append(f"{lo}-{hi} BPM")
        parts.append("clean mix, modern production")
        header = ", ".join(parts)
        body = f'"{topic}" üzerine, Türkçe sözler, akılda kalıcı nakarat, 2 verse + chorus + bridge.'
        return f"Suno prompt:\n[{header}]\n{body}"

    if t == "lyrics_skeleton":
        topic_line = topic or "anlatmak istediğin his"
        return (
            f"Şarkı iskeleti — konu: {topic_line}\n"
            "Verse 1:\n  [4 satır — sahneyi kur]\n"
            "Pre-Chorus:\n  [2 satır — yükselt]\n"
            "Chorus:\n  [4 satır — akılda kalan ana mesaj]\n"
            "Verse 2:\n  [4 satır — derinleştir]\n"
            "Chorus (tekrar)\n"
            "Bridge:\n  [2-4 satır — perspektif değişimi]\n"
            "Chorus (final, varyasyon)\n"
        )

    if t == "cover_idea":
        m = mood or "yalın"
        s = style or "modern"
        return (
            f"Kapak fikri ({s}, {m}): merkezde tek figür, "
            "yumuşak renk geçişleri (lacivert→mor), grain dokusu, "
            "şarkı adı sade serif font, alt köşede sanatçı adı küçük."
        )

    return f"Bilinmeyen müzik görevi: {task}"
