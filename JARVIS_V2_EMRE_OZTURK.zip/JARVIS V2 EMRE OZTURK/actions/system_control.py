"""
Basit sistem kontrolü — ses, kilit, uyku, ekran kapatma, kopyala/yapıştır vb.
Tek bir 'system_control' tool'u üzerinden yönetilir.
"""

from __future__ import annotations
import subprocess


def _run(cmd: str) -> str:
    try:
        out = subprocess.run(cmd, shell=True, capture_output=True, text=True, timeout=15)
        return (out.stdout or out.stderr or "").strip()
    except Exception as e:
        return f"Hata: {e}"


def _set_volume(level: int) -> str:
    level = max(0, min(100, int(level)))
    try:
        from ctypes import cast, POINTER  # type: ignore
        from comtypes import CLSCTX_ALL  # type: ignore
        from pycaw.pycaw import AudioUtilities, IAudioEndpointVolume  # type: ignore
        devices = AudioUtilities.GetSpeakers()
        interface = devices.Activate(IAudioEndpointVolume._iid_, CLSCTX_ALL, None)
        vol = cast(interface, POINTER(IAudioEndpointVolume))
        vol.SetMasterVolumeLevelScalar(level / 100.0, None)
        return f"Ses seviyesi %{level} olarak ayarlandı."
    except Exception:
        # Fallback: PowerShell ile sanal tuş gönder
        steps = level // 2
        ps = (
            "$ws = New-Object -ComObject WScript.Shell; "
            "for ($i=0; $i -lt 50; $i++) { $ws.SendKeys([char]174) }; "
            f"for ($i=0; $i -lt {steps}; $i++) {{ $ws.SendKeys([char]175) }}"
        )
        subprocess.run(["powershell", "-WindowStyle", "Hidden", "-Command", ps], timeout=20)
        return f"Ses seviyesi yaklaşık %{level} olarak ayarlandı."


def _mute_toggle() -> str:
    ps = "(New-Object -ComObject WScript.Shell).SendKeys([char]173)"
    subprocess.run(["powershell", "-WindowStyle", "Hidden", "-Command", ps], timeout=10)
    return "Ses sustur/aç tuşu gönderildi."


def system_control(action: str, value: str = "") -> str:
    """
    action: 'volume_up' | 'volume_down' | 'volume_set' | 'mute' |
            'lock' | 'sleep' | 'screen_off' | 'sign_out' |
            'restart' | 'shutdown' | 'empty_recycle_bin'
    value: volume_set için 0-100 arasında sayı (string olarak)
    """
    a = (action or "").strip().lower()

    if a == "volume_up":
        ps = "(New-Object -ComObject WScript.Shell).SendKeys([char]175)"
        for _ in range(5):
            subprocess.run(["powershell", "-WindowStyle", "Hidden", "-Command", ps], timeout=5)
        return "Ses arttırıldı."

    if a == "volume_down":
        ps = "(New-Object -ComObject WScript.Shell).SendKeys([char]174)"
        for _ in range(5):
            subprocess.run(["powershell", "-WindowStyle", "Hidden", "-Command", ps], timeout=5)
        return "Ses azaltıldı."

    if a == "volume_set":
        try:
            return _set_volume(int(float(value)))
        except Exception:
            return "Geçersiz ses değeri. 0-100 arası bir sayı verin."

    if a == "mute":
        return _mute_toggle()

    if a == "lock":
        _run("rundll32.exe user32.dll,LockWorkStation")
        return "Bilgisayar kilitlendi."

    if a == "sleep":
        _run("rundll32.exe powrprof.dll,SetSuspendState 0,1,0")
        return "Uyku moduna geçildi."

    if a == "screen_off":
        ps = "(Add-Type '[DllImport(\"user32.dll\")]public static extern int SendMessage(int hWnd,int hMsg,int wParam,int lParam);' -Name a -Pass)::SendMessage(-1,0x0112,0xF170,2)"
        subprocess.run(["powershell", "-WindowStyle", "Hidden", "-Command", ps], timeout=10)
        return "Ekran kapatıldı."

    if a == "sign_out":
        _run("shutdown /l")
        return "Oturum kapatılıyor."

    if a == "restart":
        _run("shutdown /r /t 5")
        return "Bilgisayar 5 saniye içinde yeniden başlatılacak."

    if a == "shutdown":
        _run("shutdown /s /t 5")
        return "Bilgisayar 5 saniye içinde kapatılacak."

    if a == "empty_recycle_bin":
        ps = "Clear-RecycleBin -Force -ErrorAction SilentlyContinue"
        subprocess.run(["powershell", "-WindowStyle", "Hidden", "-Command", ps], timeout=20)
        return "Geri dönüşüm kutusu boşaltıldı."

    return f"Bilinmeyen sistem komutu: {action}"
