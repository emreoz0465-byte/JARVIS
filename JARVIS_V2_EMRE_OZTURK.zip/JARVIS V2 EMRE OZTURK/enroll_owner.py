"""
Sahip yüzünü kaydetmek için tek seferlik script.
Kullanım: venv aktifken `python enroll_owner.py`
Webcam açılır, ~10 saniye boyunca yüz örnekleri alınır.
"""

from actions.face_recognition_owner import enroll_owner

if __name__ == "__main__":
    print("[Enroll] Kameraya bakın, başınızı hafifçe sağa-sola çevirin...")
    msg = enroll_owner(samples=25)
    print("[Enroll]", msg)
