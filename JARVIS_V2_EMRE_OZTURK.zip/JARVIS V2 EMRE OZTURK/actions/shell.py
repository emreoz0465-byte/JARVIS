"""
Terminal komutu çalıştırma — Windows cmd/PowerShell
"""

import os
import subprocess

from path_utils import expand_known_folder_aliases, known_folder_env


BLOCKED = []


def shell_run(command: str, timeout: int = 30) -> str:
    if not command:
        return "Komut belirtilmedi."

    normalized_command = expand_known_folder_aliases(command)
    cmd_lower = normalized_command.lower().strip()

    for blocked in BLOCKED:
        if blocked in cmd_lower:
            return f"Güvenlik: Bu komut engellendi → {blocked}"

    try:
        env = os.environ.copy()
        env.update(known_folder_env())
        result = subprocess.run(
            normalized_command,
            shell=True,
            capture_output=True,
            text=True,
            timeout=timeout,
            encoding="utf-8",
            errors="replace",
            env=env,
        )
        output = (result.stdout + result.stderr).strip()
        if not output:
            return "Komut başarıyla çalıştı (çıktı yok)."
        if len(output) > 800:
            output = output[:800] + "\n... (çıktı kısaltıldı)"
        return output
    except subprocess.TimeoutExpired:
        return f"Komut zaman aşımına uğradı ({timeout}s)."
    except Exception as e:
        return f"Hata: {e}"
