"""
JARVIS kısayol yardımcıları — Windows sürümü.

Masaüstü kısayolu  → Desktop\\JARVIS.lnk
Açılışta başlat    → Başlangıç klasörü + Windows Kayıt Defteri (HKCU\\Run)
"""

from __future__ import annotations

import os
import subprocess
import sys
import winreg
from pathlib import Path

BASE_DIR = Path(__file__).resolve().parent
_CREATE_NO_WINDOW = 0x08000000

_REG_KEY  = r"Software\Microsoft\Windows\CurrentVersion\Run"
_REG_NAME = "JARVIS_AI"


def _desktop_dir() -> Path:
    try:
        r = subprocess.run(
            ["powershell", "-NoProfile", "-ExecutionPolicy", "Bypass",
             "-Command", "[Environment]::GetFolderPath('Desktop')"],
            capture_output=True, text=True, timeout=8,
            creationflags=_CREATE_NO_WINDOW,
        )
        raw = r.stdout.strip().strip('"')
        if r.returncode == 0 and raw:
            p = Path(raw)
            if p.exists():
                return p
    except Exception:
        pass
    for env in ("USERPROFILE", "HOMEPATH"):
        base = os.environ.get(env)
        if base:
            for sub in ("Desktop", "Masaüstü", "Masaustu"):
                p = Path(base) / sub
                if p.exists():
                    return p
    od = os.environ.get("OneDrive") or os.environ.get("OneDriveConsumer")
    if od:
        for sub in ("Desktop", "Masaüstü", "Masaustu"):
            p = Path(od) / sub
            if p.exists():
                return p
    return Path.home() / "Desktop"


def _startup_dir() -> Path:
    return (
        Path(os.environ.get("APPDATA", str(Path.home())))
        / "Microsoft" / "Windows" / "Start Menu" / "Programs" / "Startup"
    )


def _pythonw() -> str:
    exe = Path(sys.executable)
    pyw = exe.with_name("pythonw.exe")
    return str(pyw if pyw.exists() else exe)


def _write_lnk_powershell(link_path: Path) -> bool:
    target  = _pythonw()
    main_py = BASE_DIR / "main.py"
    ico = BASE_DIR / "Icon" / "jarvis.ico"
    icon_line = f'$s.IconLocation = "{ico}"; ' if ico.exists() else ""
    ps = (
        '$ws = New-Object -ComObject WScript.Shell; '
        f'$s = $ws.CreateShortcut("{link_path}"); '
        f'$s.TargetPath = "{target}"; '
        f'$s.Arguments = \'"{main_py}"\'; '
        f'$s.WorkingDirectory = "{BASE_DIR}"; '
        f'$s.Description = "J.A.R.V.I.S"; '
        f'{icon_line}'
        '$s.Save()'
    )
    try:
        r = subprocess.run(
            ["powershell", "-NoProfile", "-ExecutionPolicy", "Bypass", "-Command", ps],
            capture_output=True, text=True, timeout=20,
            creationflags=_CREATE_NO_WINDOW,
        )
        return r.returncode == 0 and link_path.exists()
    except Exception:
        return False


def _write_lnk_vbs(link_path: Path) -> bool:
    target  = _pythonw()
    main_py = BASE_DIR / "main.py"
    vbs = f'''Set ws = CreateObject("WScript.Shell")
Set sc = ws.CreateShortcut("{link_path}")
sc.TargetPath = "{target}"
sc.Arguments = """{main_py}"""
sc.WorkingDirectory = "{BASE_DIR}"
sc.Description = "J.A.R.V.I.S"
sc.Save
'''
    vbs_path = BASE_DIR / "_tmp_jarvis_lnk.vbs"
    try:
        vbs_path.write_text(vbs, encoding="utf-8")
        r = subprocess.run(
            ["cscript", "//NoLogo", str(vbs_path)],
            capture_output=True, text=True, timeout=15,
            creationflags=_CREATE_NO_WINDOW,
        )
        return r.returncode == 0 and link_path.exists()
    except Exception:
        return False
    finally:
        try:
            vbs_path.unlink(missing_ok=True)
        except Exception:
            pass


def _write_shortcut(link_path: Path) -> Path:
    link_path.parent.mkdir(parents=True, exist_ok=True)
    if _write_lnk_powershell(link_path):
        return link_path
    if _write_lnk_vbs(link_path):
        return link_path
    bat = link_path.with_suffix(".bat")
    bat.write_text(
        f'@echo off\nstart "" "{_pythonw()}" "{BASE_DIR / "main.py"}"\n',
        encoding="utf-8"
    )
    if bat.exists():
        return bat
    raise RuntimeError("Kısayol oluşturulamadı.")


def desktop_shortcut_path() -> Path:
    return _desktop_dir() / "JARVIS.lnk"


def create_desktop_shortcut() -> Path:
    return _write_shortcut(desktop_shortcut_path())


def startup_shortcut_path() -> Path:
    return _startup_dir() / "JARVIS.lnk"


def _startup_bat_path() -> Path:
    return _startup_dir() / "JARVIS.bat"


def _reg_add_startup() -> bool:
    try:
        cmd = f'"{_pythonw()}" "{BASE_DIR / "main.py"}"'
        with winreg.OpenKey(winreg.HKEY_CURRENT_USER, _REG_KEY, 0, winreg.KEY_SET_VALUE) as key:
            winreg.SetValueEx(key, _REG_NAME, 0, winreg.REG_SZ, cmd)
        return True
    except Exception:
        return False


def _reg_remove_startup() -> None:
    try:
        with winreg.OpenKey(winreg.HKEY_CURRENT_USER, _REG_KEY, 0, winreg.KEY_SET_VALUE) as key:
            winreg.DeleteValue(key, _REG_NAME)
    except Exception:
        pass


def _reg_startup_exists() -> bool:
    try:
        with winreg.OpenKey(winreg.HKEY_CURRENT_USER, _REG_KEY, 0, winreg.KEY_READ) as key:
            winreg.QueryValueEx(key, _REG_NAME)
            return True
    except Exception:
        return False


def create_startup_shortcut() -> Path:
    _startup_dir().mkdir(parents=True, exist_ok=True)
    _reg_add_startup()
    lnk_path = startup_shortcut_path()
    try:
        _write_shortcut(lnk_path)
    except Exception:
        pass
    if not lnk_path.exists() and not _reg_startup_exists():
        _startup_bat_path().write_text(
            f'@echo off\nstart "" "{_pythonw()}" "{BASE_DIR / "main.py"}"\n',
            encoding="utf-8"
        )
    return lnk_path


def remove_startup_shortcut() -> None:
    _reg_remove_startup()
    for p in (startup_shortcut_path(), _startup_bat_path()):
        try:
            if p.exists():
                p.unlink()
        except Exception:
            pass


def is_startup_installed() -> bool:
    if _reg_startup_exists():
        return True
    if startup_shortcut_path().exists():
        return True
    if _startup_bat_path().exists():
        return True
    return False


if __name__ == "__main__":
    created = create_desktop_shortcut()
    print(f"Masaüstü kısayolu oluşturuldu: {created}")
