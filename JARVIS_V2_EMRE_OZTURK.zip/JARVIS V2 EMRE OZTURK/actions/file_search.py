"""
Doğal dil dosya arama — Masaüstü/İndirilenler/Belgeler/Resimler/Müzik/Videolar.
Anahtar kelime, uzantı ve son düzenleme tarihine göre filtreler.
"""

from __future__ import annotations
import os
import re
import time
from pathlib import Path

try:
    from path_utils import (
        get_desktop_dir, get_documents_dir, get_downloads_dir,
        get_pictures_dir, get_music_dir, get_videos_dir,
    )
except Exception:
    def _h(name): return Path.home() / name
    def get_desktop_dir():   return _h("Desktop")
    def get_documents_dir(): return _h("Documents")
    def get_downloads_dir(): return _h("Downloads")
    def get_pictures_dir():  return _h("Pictures")
    def get_music_dir():     return _h("Music")
    def get_videos_dir():    return _h("Videos")


EXT_GROUPS = {
    "pdf":     {".pdf"},
    "belge":   {".doc", ".docx", ".odt", ".rtf", ".txt", ".md"},
    "sunum":   {".ppt", ".pptx", ".odp", ".key"},
    "tablo":   {".xls", ".xlsx", ".ods", ".csv"},
    "resim":   {".jpg", ".jpeg", ".png", ".gif", ".bmp", ".webp", ".heic"},
    "video":   {".mp4", ".mov", ".mkv", ".avi", ".webm"},
    "muzik":   {".mp3", ".wav", ".flac", ".m4a", ".ogg"},
    "arsiv":   {".zip", ".rar", ".7z", ".tar", ".gz"},
    "kod":     {".py", ".js", ".ts", ".tsx", ".jsx", ".html", ".css", ".java", ".cpp", ".cs", ".rs", ".go"},
}

LOCATION_KEYWORDS = {
    "masaustu":    ["masaüstü", "masaustu", "desktop"],
    "indirilenler":["indirilenler", "indirilen", "downloads"],
    "belgeler":    ["belgeler", "documents", "evrak"],
    "resimler":    ["resimler", "fotograf", "fotoğraf", "pictures"],
    "muzik":       ["müzik", "muzik", "music", "şarkı", "sarki"],
    "videolar":    ["video", "videolar", "film"],
}


def _resolve_locations(query: str) -> list[Path]:
    q = query.lower()
    found = []
    if any(k in q for k in LOCATION_KEYWORDS["masaustu"]):    found.append(get_desktop_dir())
    if any(k in q for k in LOCATION_KEYWORDS["indirilenler"]):found.append(get_downloads_dir())
    if any(k in q for k in LOCATION_KEYWORDS["belgeler"]):    found.append(get_documents_dir())
    if any(k in q for k in LOCATION_KEYWORDS["resimler"]):    found.append(get_pictures_dir())
    if any(k in q for k in LOCATION_KEYWORDS["muzik"]):       found.append(get_music_dir())
    if any(k in q for k in LOCATION_KEYWORDS["videolar"]):    found.append(get_videos_dir())

    if not found:
        # varsayılan: en sık üç konum
        found = [get_desktop_dir(), get_downloads_dir(), get_documents_dir()]
    return [p for p in found if p and p.exists()]


def _resolve_extensions(query: str) -> set[str]:
    q = query.lower()
    exts: set[str] = set()
    for label, group in EXT_GROUPS.items():
        if label in q:
            exts |= group
    # explicit .pdf vs.
    for m in re.findall(r"\.([a-z0-9]{2,5})\b", q):
        exts.add("." + m)
    return exts


_FILLER = {
    "bul", "ara", "listele", "göster", "goster", "getir", "ver",
    "tüm", "tum", "bütün", "butun", "bana", "deki", "daki",
    "masaüstü", "masaustu", "desktop", "indirilenler", "indirilen", "downloads",
    "belgeler", "documents", "resimler", "müzik", "muzik", "video", "videolar",
    "dosya", "dosyaları", "dosyalari", "pdf", "belge", "sunum", "tablo",
    "resim", "muzik", "arsiv", "kod", "the", "a", "an",
}


def _keywords(query: str) -> list[str]:
    q = re.sub(r"[^\wçğıöşüÇĞİÖŞÜ\s]", " ", query.lower())
    tokens = [t for t in q.split() if t and t not in _FILLER and len(t) >= 2]
    return tokens


def find_files(query: str, limit: int = 20, days: int = 0) -> str:
    """
    Doğal dil sorgudan dosya listesi döndürür.
    days > 0 ise sadece son N gün içinde düzenlenmiş dosyaları getirir.
    """
    if not query or not query.strip():
        return "Arama sorgusu boş."

    locations = _resolve_locations(query)
    exts      = _resolve_extensions(query)
    kws       = _keywords(query)
    cutoff    = (time.time() - days * 86400) if days > 0 else 0.0

    results = []
    for loc in locations:
        for root, dirs, files in os.walk(loc):
            # gizli ve sistem klasörlerini atla
            dirs[:] = [d for d in dirs if not d.startswith(".") and d.lower() not in {"node_modules", "venv", "__pycache__"}]
            for fname in files:
                low = fname.lower()
                if exts and not any(low.endswith(e) for e in exts):
                    continue
                if kws and not all(k in low for k in kws):
                    # daha gevşek: en az bir kelime eşleşsin
                    if not any(k in low for k in kws):
                        continue
                full = Path(root) / fname
                try:
                    mt = full.stat().st_mtime
                except OSError:
                    continue
                if cutoff and mt < cutoff:
                    continue
                results.append((mt, full))
                if len(results) >= 500:
                    break
            if len(results) >= 500:
                break

    if not results:
        return "Eşleşen dosya bulunamadı."

    results.sort(key=lambda r: r[0], reverse=True)
    top = results[:max(1, limit)]
    lines = [f"{len(results)} dosya bulundu, en yeni {len(top)}:"]
    for mt, p in top:
        ts = time.strftime("%Y-%m-%d", time.localtime(mt))
        try:
            size_kb = p.stat().st_size // 1024
        except OSError:
            size_kb = 0
        lines.append(f"  - {p.name}  ({size_kb} KB, {ts})  → {p.parent}")
    return "\n".join(lines)
