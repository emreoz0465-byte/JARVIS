"""
Uzman modları — Kod, Müzik, İçerik (ve Genel).
Aktif mod bir JSON dosyasında saklanır; main.py system prompt'a ekler.
"""

from __future__ import annotations
import json
from pathlib import Path

BASE_DIR  = Path(__file__).resolve().parent.parent
STATE_DIR = BASE_DIR / "memory"
STATE_FILE = STATE_DIR / "expert_mode.json"

MODES = {
    "genel": (
        "Genel mod aktif. Her konuda dengeli, kısa ve net cevap ver."
    ),
    "kod": (
        "KOD MODU aktif. Bir senior yazılım mühendisi gibi davran:\n"
        "- Cevaplarında çalışan, minimal ve okunabilir kod örnekleri ver.\n"
        "- Dil/framework tespit et, en iyi pratikleri uygula.\n"
        "- Hata mesajlarını analiz et, kök nedeni açıkla, çözüm öner.\n"
        "- Mümkünse alternatifleri kısa karşılaştır."
    ),
    "muzik": (
        "MÜZİK MODU aktif. Bir müzik yapımcısı/söz yazarı gibi davran:\n"
        "- Tarz, BPM, akor ilerleyişi, mix önerileri ver.\n"
        "- İstenirse Suno prompt veya şarkı sözü iskeleti üret (music_helper aracını kullan).\n"
        "- Türkçe sözlerde uyak ve hece akışına dikkat et."
    ),
    "icerik": (
        "İÇERİK MODU aktif. Bir içerik üreticisi/sosyal medya stratejisti gibi davran:\n"
        "- Başlık, hook, açıklama ve hashtag önerileri ver.\n"
        "- Kısa video (Reels/Shorts/TikTok) için 15-30 sn'lik senaryo iskeleti yaz.\n"
        "- CTA ve thumbnail önerisi ekle."
    ),
}


def _load() -> dict:
    try:
        if STATE_FILE.exists():
            return json.loads(STATE_FILE.read_text(encoding="utf-8"))
    except Exception:
        pass
    return {"mode": "genel"}


def _save(d: dict):
    STATE_DIR.mkdir(parents=True, exist_ok=True)
    STATE_FILE.write_text(json.dumps(d, ensure_ascii=False, indent=2), encoding="utf-8")


def get_current_mode() -> str:
    return _load().get("mode", "genel")


def get_mode_instruction(mode: str | None = None) -> str:
    m = (mode or get_current_mode()).strip().lower()
    return MODES.get(m, MODES["genel"])


def set_expert_mode(mode: str) -> str:
    """Tool: aktif uzman modunu değiştirir."""
    m = (mode or "").strip().lower()
    if m not in MODES:
        return f"Geçersiz mod: {mode}. Geçerli modlar: {', '.join(MODES.keys())}."
    _save({"mode": m})
    return f"Uzman modu '{m}' olarak ayarlandı. Bir sonraki konuşma turunda etkin olacak."
