from __future__ import annotations

import os
import re
import subprocess
from functools import lru_cache
from pathlib import Path


_CREATE_NO_WINDOW = getattr(subprocess, "CREATE_NO_WINDOW", 0)

_KNOWN_FOLDERS = {
    "desktop": {
        "ps_name": "Desktop",
        "env_name": "JARVIS_DESKTOP",
        "aliases": ["Desktop", "Masaüstü", "Masaustu"],
        "subdirs": ["Desktop"],
        "onedrive": True,
    },
    "documents": {
        "ps_name": "MyDocuments",
        "env_name": "JARVIS_DOCUMENTS",
        "aliases": ["Documents", "Document", "Belgeler"],
        "subdirs": ["Documents", "Belgeler"],
        "onedrive": True,
    },
    "downloads": {
        "ps_name": "",
        "env_name": "JARVIS_DOWNLOADS",
        "aliases": ["Downloads", "İndirilenler", "Indirilenler"],
        "subdirs": ["Downloads", "İndirilenler", "Indirilenler"],
        "onedrive": False,
    },
    "pictures": {
        "ps_name": "MyPictures",
        "env_name": "JARVIS_PICTURES",
        "aliases": ["Pictures", "Resimler"],
        "subdirs": ["Pictures", "Resimler"],
        "onedrive": True,
    },
    "music": {
        "ps_name": "MyMusic",
        "env_name": "JARVIS_MUSIC",
        "aliases": ["Music", "Müzik", "Muzik"],
        "subdirs": ["Music", "Müzik", "Muzik"],
        "onedrive": False,
    },
    "videos": {
        "ps_name": "MyVideos",
        "env_name": "JARVIS_VIDEOS",
        "aliases": ["Videos", "Videolar"],
        "subdirs": ["Videos", "Videolar"],
        "onedrive": False,
    },
}


@lru_cache(maxsize=None)
def _powershell_known_folder(ps_name: str) -> Path | None:
    if not ps_name:
        return None
    try:
        result = subprocess.run(
            [
                "powershell",
                "-NoProfile",
                "-Command",
                f"[Environment]::GetFolderPath('{ps_name}')",
            ],
            capture_output=True,
            text=True,
            encoding="utf-8",
            errors="replace",
            timeout=8,
            creationflags=_CREATE_NO_WINDOW,
        )
        raw = (result.stdout or "").strip().strip('"')
        if result.returncode == 0 and raw:
            return Path(raw)
    except Exception:
        pass
    return None


def resolve_known_folder(folder_key: str) -> Path:
    key = str(folder_key or "").strip().lower()
    meta = _KNOWN_FOLDERS.get(key)
    if not meta:
        raise KeyError(f"Bilinmeyen klasör anahtarı: {folder_key}")

    candidates: list[Path] = []

    ps_path = _powershell_known_folder(meta["ps_name"])
    if ps_path:
        candidates.append(ps_path)

    user_profile = Path(os.environ.get("USERPROFILE", str(Path.home())))
    one_drive = os.environ.get("OneDrive") or os.environ.get("OneDriveConsumer")

    if meta.get("onedrive") and one_drive:
        one_drive_path = Path(one_drive)
        for subdir in meta["subdirs"]:
            candidates.append(one_drive_path / subdir)

    for subdir in meta["subdirs"]:
        candidates.append(user_profile / subdir)

    if key == "downloads":
        candidates.append(Path.home() / "Downloads")

    for candidate in candidates:
        if candidate.exists():
            return candidate

    return candidates[0]


def known_folder_env() -> dict[str, str]:
    env: dict[str, str] = {}
    for key, meta in _KNOWN_FOLDERS.items():
        try:
            resolved = resolve_known_folder(key)
            env[meta["env_name"]] = str(resolved)
        except Exception:
            continue
    return env


def expand_known_folder_aliases(command: str) -> str:
    text = str(command or "")
    if not text:
        return text

    replacements: list[tuple[re.Pattern[str], str]] = []

    for key, meta in _KNOWN_FOLDERS.items():
        resolved = str(resolve_known_folder(key))
        aliases = meta["aliases"]

        for alias in aliases:
            replacements.append(
                (
                    re.compile(
                        rf"(?i)%USERPROFILE%\\{re.escape(alias)}(?=\\|/|\"|'|$)"
                    ),
                    resolved,
                )
            )
            replacements.append(
                (
                    re.compile(
                        rf"(?i)%HOMEPATH%\\{re.escape(alias)}(?=\\|/|\"|'|$)"
                    ),
                    resolved,
                )
            )
            replacements.append(
                (
                    re.compile(
                        rf"(?i)(?:(?<=^)|(?<=[\s\"'=])){re.escape(alias)}(?=\\|/)"
                    ),
                    resolved,
                )
            )

    normalized = text
    for pattern, replacement in replacements:
        normalized = pattern.sub(lambda _m, rep=replacement: rep, normalized)

    return normalized
