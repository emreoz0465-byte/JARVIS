"""
Yüz tanıma — sahibi (Emre ÖZTÜRK) tanıyıp karşılar.
OpenCV LBPH (opencv-contrib-python) ile çalışır; dlib gerektirmez.
Kayıt: enroll_owner() — webcam'den birkaç kare alıp model dosyasını üretir.
Tanıma: detect_owner(timeout_sec=4) -> ("emre_ozturk" | "unknown" | "no_face")
"""

from __future__ import annotations
import os
import time
from pathlib import Path

BASE_DIR   = Path(__file__).resolve().parent.parent
DATA_DIR   = BASE_DIR / "memory" / "face_data"
MODEL_PATH = DATA_DIR / "owner_model.yml"
LABELS_PATH = DATA_DIR / "labels.txt"
OWNER_NAME = "Emre ÖZTÜRK"
OWNER_ID   = 1


def _ensure_dirs():
    DATA_DIR.mkdir(parents=True, exist_ok=True)


def _get_cv2():
    try:
        import cv2  # type: ignore
        return cv2
    except Exception:
        return None


def _haar_cascade(cv2):
    path = os.path.join(cv2.data.haarcascades, "haarcascade_frontalface_default.xml")
    return cv2.CascadeClassifier(path)


def _open_cam(cv2):
    for be_name in ("CAP_DSHOW", "CAP_MSMF", "CAP_ANY"):
        be = getattr(cv2, be_name, 0)
        for idx in (0, 1, 2):
            cap = cv2.VideoCapture(idx, be) if be else cv2.VideoCapture(idx)
            if cap is not None and cap.isOpened():
                # warmup
                for _ in range(4):
                    cap.read()
                return cap
    return None


def is_owner_registered() -> bool:
    return MODEL_PATH.exists()


def enroll_owner(samples: int = 25) -> str:
    """Webcam'den birkaç kare alıp sahibi kaydeder."""
    cv2 = _get_cv2()
    if cv2 is None:
        return "opencv-python yüklü değil."
    if not hasattr(cv2, "face"):
        return "opencv-contrib-python gerekli (cv2.face yok). setup.bat'i tekrar çalıştırın."

    _ensure_dirs()
    cap = _open_cam(cv2)
    if cap is None:
        return "Kamera açılamadı."

    cascade = _haar_cascade(cv2)
    faces_collected = []
    start = time.time()
    while len(faces_collected) < samples and time.time() - start < 15:
        ok, frame = cap.read()
        if not ok:
            continue
        gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
        rects = cascade.detectMultiScale(gray, 1.2, 5, minSize=(80, 80))
        if len(rects) > 0:
            x, y, w, h = max(rects, key=lambda r: r[2] * r[3])
            face = cv2.resize(gray[y:y + h, x:x + w], (200, 200))
            faces_collected.append(face)
        time.sleep(0.08)
    cap.release()

    if len(faces_collected) < 5:
        return "Yeterli yüz örneği alınamadı. Kameraya bakıp tekrar deneyin."

    recognizer = cv2.face.LBPHFaceRecognizer_create()
    import numpy as np  # type: ignore
    recognizer.train(faces_collected, np.array([OWNER_ID] * len(faces_collected)))
    recognizer.write(str(MODEL_PATH))
    LABELS_PATH.write_text(f"{OWNER_ID}={OWNER_NAME}\n", encoding="utf-8")
    return f"{OWNER_NAME} yüzü kaydedildi ({len(faces_collected)} örnek)."


def detect_owner(timeout_sec: float = 4.0, confidence_threshold: float = 75.0) -> str:
    """
    Kamerayı kısa süre açıp sahibi arar.
    Dönüş: 'owner' | 'unknown' | 'no_face' | 'unavailable'
    """
    cv2 = _get_cv2()
    if cv2 is None or not hasattr(cv2, "face"):
        return "unavailable"
    if not MODEL_PATH.exists():
        return "unavailable"

    recognizer = cv2.face.LBPHFaceRecognizer_create()
    try:
        recognizer.read(str(MODEL_PATH))
    except Exception:
        return "unavailable"

    cap = _open_cam(cv2)
    if cap is None:
        return "unavailable"

    cascade = _haar_cascade(cv2)
    result = "no_face"
    start = time.time()
    try:
        while time.time() - start < timeout_sec:
            ok, frame = cap.read()
            if not ok:
                continue
            gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
            rects = cascade.detectMultiScale(gray, 1.2, 5, minSize=(80, 80))
            if len(rects) == 0:
                continue
            x, y, w, h = max(rects, key=lambda r: r[2] * r[3])
            face = cv2.resize(gray[y:y + h, x:x + w], (200, 200))
            label, conf = recognizer.predict(face)
            # LBPH: küçük conf = iyi eşleşme
            if label == OWNER_ID and conf < confidence_threshold:
                return "owner"
            result = "unknown"
    finally:
        cap.release()
    return result
